<div>
    <div class="grid grid-cols-12 gap-3">
        <div class="col-span-12">
            <?php if(Session::has('message')): ?>
                <p class="backdrop border border-green-300 h-8 bg-white bg-opacity-10 p-2 rounded "><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
        </div>
        <div class="col-span-12">
            <label for="">Quiz Name</label>
            
            <input type="hidden" wire:model="hiddenId">
            <input type="text" wire:model="quiz_name" class="w-full rounded backdrop border border-green-300 h-8 bg-white bg-opacity-10 focus:outline-none px-2" placeholder="quiz name">
            <?php $__errorArgs = ['quiz_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-span-12">
            <label for="">Quiz One</label>
            <input type="text" wire:model="quiz_one" class="w-full rounded backdrop border border-green-300 h-8 bg-white bg-opacity-10 focus:outline-none px-2" placeholder="quiz one">
            <?php $__errorArgs = ['quiz_one'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-span-12">
            <label for="">Quiz Two</label>
            <input type="text" wire:model="quiz_two" class="w-full rounded backdrop border border-green-300 h-8 bg-white bg-opacity-10 focus:outline-none px-2" placeholder="quiz two">
            <?php $__errorArgs = ['quiz_two'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-span-12">
            <label for="">Quiz Three</label>
            <input type="text" wire:model="quiz_three" class="w-full rounded backdrop border border-green-300 h-8 bg-white bg-opacity-10 focus:outline-none px-2" placeholder="quiz three">
            <?php $__errorArgs = ['quiz_three'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-span-12">
            <label for="">Quiz Four</label>
            <input type="text" wire:model="quiz_four" class="w-full rounded backdrop border border-green-300 h-8 bg-white bg-opacity-10 focus:outline-none px-2" placeholder="quiz four">
            <?php $__errorArgs = ['quiz_four'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-red-500"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-span-12">
           <button type="submit" wire:click="update()" class="text-center text-white w-full rounded backdrop border border-green-300 h-10 bg-white bg-opacity-10 focus:outline-none px-2 shadow p-2 ">Update Quiz</button>
        </div>
        <div class="col-span-12">
           <button type="submit" wire:click="submit()" class="text-center text-white w-full rounded backdrop border border-green-300 h-10 bg-white bg-opacity-10 focus:outline-none px-2 shadow p-2 ">submit Quiz</button>
        </div>
    </div>
</div>
<?php /**PATH D:\Laragon-dev\www\quiz-app\resources\views/livewire/update.blade.php ENDPATH**/ ?>