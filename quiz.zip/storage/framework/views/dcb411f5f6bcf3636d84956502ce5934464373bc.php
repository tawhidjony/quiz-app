<div>
    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $data_exam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li>
            <?php echo e($row->quiz_name); ?><br>
            <ol>
                <input type="radio" name="ans-<?php echo e($row->id); ?>[]" >
                <label for=""><?php echo e($row->quiz_ans_one); ?></label>
            </ol>
            <ol>
                <input type="radio" name="ans-<?php echo e($row->id); ?>[]" >
                <label for=""><?php echo e($row->quiz_ans_two); ?></label>
            </ol>
            <ol>
                <input type="radio" name="ans-<?php echo e($row->id); ?>[]" >
                <label for=""> <?php echo e($row->quiz_ans_three); ?></label>
            </ol>
            <ol>
                <input type="radio" name="ans-<?php echo e($row->id); ?>[]" >
                <label for=""><?php echo e($row->quiz_ans_four); ?></label>
            </ol>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <?php endif; ?>

    </ul>
</div>
<?php /**PATH D:\Laragon-dev\www\quiz-app\resources\views/livewire/exam-paper.blade.php ENDPATH**/ ?>