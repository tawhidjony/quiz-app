<div class="grid grid-cols-12 gap-4 mx-10 my-6">
    <div class="col-span-12 md:col-span-8 ">
        <div class="backdrop bg-white bg-opacity-10 text-white border">
            <table class="min-w-full">
                <thead class="bg-gradient-to-r from-green-400 to-blue-500 rounded">
                    <tr>
                        <th class="px-2 py-2 border-b border-gray-300 text-left text-white text-sm" >#SL</th>
                        <th class="px-2 py-2 border-b border-gray-300 text-left text-white text-sm" >Quiz Name</th>
                        <th class="px-2 py-2 border-b border-gray-300 text-left text-white text-sm" >Quiz One</th>
                        <th class="px-2 py-2 border-b border-gray-300 text-left text-white text-sm" >Quiz Two</th>
                        <th class="px-2 py-2 border-b border-gray-300 text-left text-white text-sm" >Quiz Three</th>
                        <th class="px-2 py-2 border-b border-gray-300 text-left text-white text-sm" >Quiz Four</th>
                        <th class="px-2 py-2 border-b border-gray-300 text-left text-white text-sm" >Action</th>
                    </tr>
                </thead>
                <tbody class="backdrop bg-white bg-opacity-10">
                    <?php $__empty_1 = true; $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th class="px-2 py-2 whitespace-no-wrap border-b text-white border-gray-500 text-sm"> <?php echo e($key + 1); ?></th>
                        <td class="px-2 py-2 whitespace-no-wrap border-b text-white border-gray-500 text-sm"> <?php echo e(Str::limit($quiz->quiz_name, 10)); ?></td>
                        <td class="px-2 py-2 whitespace-no-wrap border-b text-white border-gray-500 text-sm"> <?php echo e(Str::limit($quiz->quiz_ans_one ,8)); ?></td>
                        <td class="px-2 py-2 whitespace-no-wrap border-b text-white border-gray-500 text-sm"> <?php echo e(Str::limit($quiz->quiz_ans_two ,8)); ?></td>
                        <td class="px-2 py-2 whitespace-no-wrap border-b text-white border-gray-500 text-sm"> <?php echo e(Str::limit($quiz->quiz_ans_three ,8)); ?></td>
                        <td class="px-2 py-2 whitespace-no-wrap border-b text-white border-gray-500 text-sm"> <?php echo e(Str::limit($quiz->quiz_ans_four ,8)); ?></td>
                        <td class="px-2 py-2 whitespace-no-wrap border-b text-white border-gray-500 text-sm">
                            <div class="flex flex-row">
                               <button type="button" class="focus:outline-none hover:text-green-600" wire:click="edit(<?php echo e($quiz->id); ?>)" ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg></button>
                               <button type="button" class="ml-2 focus:outline-none hover:text-red-600" wire:click="destroy(<?php echo e($quiz->id); ?>)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg></button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>no data available</p>
                    <?php endif; ?>
                </tbody>
            </table>


<?php if($quizzes->hasPages()): ?>
    <nav role="navigation" aria-label="Pagination Navigation" class="flex justify-start my-2 mx-2">
        
        <?php if($quizzes->onFirstPage()): ?>
            <div class="backdrop border border-green-300 bg-white bg-opacity-40 p-2 rounded ">
            <?php echo __('pagination.previous'); ?>

            </div>
        <?php else: ?>
            <a href="<?php echo e($quizzes->previousPageUrl()); ?>" rel="prev" class="backdrop border border-green-300 bg-indigo-900 bg-opacity-40 p-2 rounded ">
            <?php echo __('pagination.previous'); ?>

            </a>
        <?php endif; ?>

        
        <?php if($quizzes->hasMorePages()): ?>
        <a href="<?php echo e($quizzes->nextPageUrl()); ?>" rel="next" class="ml-2 backdrop border border-green-300 bg-indigo-900 bg-opacity-40 p-2 rounded ">
        <?php echo __('pagination.next'); ?>

        </a>
        <?php else: ?>
        <span class="backdrop border border-green-300 bg-white bg-opacity-40 p-2 rounded ">
        <?php echo __('pagination.next'); ?>

        </span>
        <?php endif; ?>
    </nav>
<?php endif; ?>
        </div>
    </div>

    <div class="col-span-12 md:col-span-4 backdrop bg-white bg-opacity-10 rounded p-3 text-white border border-gray-300 shadow-lg">

        <?php if($updateMode): ?>
            <?php echo $__env->make('livewire.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('livewire.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\Laragon-dev\www\quiz-app\resources\views/livewire/quize-add.blade.php ENDPATH**/ ?>