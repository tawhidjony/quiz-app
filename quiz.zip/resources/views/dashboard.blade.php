<x-app-layout>
     @livewire('quize-add')
</x-app-layout>
