<div>
    <ul>
        @forelse ($data_exam as $row )
        <li>
            {{$row->quiz_name}}<br>
            <ol>
                <input type="radio" name="ans-{{$row->id}}[]" >
                <label for="">{{$row->quiz_ans_one}}</label>
            </ol>
            <ol>
                <input type="radio" name="ans-{{$row->id}}[]" >
                <label for="">{{$row->quiz_ans_two}}</label>
            </ol>
            <ol>
                <input type="radio" name="ans-{{$row->id}}[]" >
                <label for=""> {{$row->quiz_ans_three}}</label>
            </ol>
            <ol>
                <input type="radio" name="ans-{{$row->id}}[]" >
                <label for="">{{$row->quiz_ans_four}}</label>
            </ol>
        </li>
        @empty

        @endforelse
        <button wire:click="store">submit</button>
    </ul>
</div>
