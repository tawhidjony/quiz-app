<?php return array (
  'exam-paper' => 'App\\Http\\Livewire\\ExamPaper',
  'quize-add' => 'App\\Http\\Livewire\\QuizeAdd',
);